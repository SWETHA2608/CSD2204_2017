# Exam2_MAD2204
Create query


tee C:/Users/719847/Downloads/LOG_Exam2_c0719847.txt;

Database name Exam_Rollnumber
